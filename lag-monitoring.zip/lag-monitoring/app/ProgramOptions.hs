{-# LANGUAGE ApplicativeDo #-}
{-# LANGUAGE NamedFieldPuns #-}

module ProgramOptions where

import Options.Applicative

data CommandLineArgs =
  CommandLineArgs
    {
      port :: Int
    , prometheusPort :: Int
   } deriving (Show)

cmdArgsParser :: Parser CommandLineArgs
cmdArgsParser = 
  CommandLineArgs 
  <$> parsePort
  <*> parsePrometheusPort
  where
    parsePort =
      fromInteger <$>
        option auto (long "port" <> short 'p' <> help "Port to run the HTTP server" <> metavar "PORT")
    parsePrometheusPort = option auto (long "prometheus-port")