{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TypeApplications #-}

module Main where

import Prelude
import Control.Lens ((^?), (^.), (.~), (&), (<&>))
import Control.Lens.Combinators (filtered, _2, folded, _1, ix)
import Control.Lens.Combinators (_Just)
import qualified Data.Text.Encoding as TE
import Data.Maybe
import Data.Aeson
import ProgramOptions (CommandLineArgs(..), cmdArgsParser)
import qualified Prometheus as P
import Network.Wai.Middleware.Prometheus ( metricsApp )
import qualified Network.HTTP.Client as NHC
import Network.HTTP.Types (status200, status422, status404)
import Network.Wai
import Network.Wai.Handler.Warp (run)
import Options.Applicative (execParser, info)
import qualified Data.ByteString.Lazy as LBS
import GHC.Generics (Generic)
import qualified Data.ByteString.Char8 as B
import qualified Data.ByteString.Lazy.Char8 as BLC
import Data.Time.Clock
import Data.Time.Clock.POSIX
import Data.Time
import Data.Time.Format (formatTime)
import qualified Data.Text.Lazy as TL
import qualified Data.Text as T
import qualified Gogol.Prelude as Core
import qualified Gogol.BigQuery.Types as GBT
import qualified Gogol.BigQuery.Jobs.Query as GBQ
import qualified Network.HTTP.Req as NHR
import Control.Monad.IO.Class
import Gogol as Google
import System.IO              (stdout)
import Network.HTTP.Client.TLS (newTlsManagerWith, tlsManagerSettings)
import Gogol.Types
import Data.Proxy
import qualified Gogol.BigQuery as GB
import Data.Aeson.Lens
import qualified Data.Vector as DV
import Control.Concurrent ( forkIO )
import Data.Functor ( void )
import Control.Lens
import Text.Read
import Config
import Control.Monad
import Database.MySQL.Simple
import Data.String



main :: IO ()
main = do
  CommandLineArgs {port, prometheusPort} <- execParser $ info cmdArgsParser mempty
  startMetricsApp prometheusPort
  run port $ app
  where
      startMetricsApp metricsPort =
            void $
                forkIO $
                    run metricsPort metricsApp

app :: Application
app request respond
  | isMetricsLagReq = do
      _ <- getDataLag
      _ <- void $ forkIO $ getDataAccuracy
      respond $ responseLBS status200 mempty (LBS.fromStrict(B.pack "Success"))
  | isHealthCheck = respond $ responseLBS status200 mempty mempty
  | otherwise = respond $ responseLBS status404 mempty mempty
  where
  isMetricsLagReq = 
    requestMethod request == "GET"
    && rawPathInfo request == "/metrics"
  isHealthCheck =
    requestMethod request == "GET"
    && rawPathInfo request == "/health"

nanosSinceEpoch :: UTCTime -> Int
nanosSinceEpoch =
    floor . (1 *) . nominalDiffTimeToSeconds . utcTimeToPOSIXSeconds


getDataLag :: IO ()
getDataLag = do
    utc_time <- getCurrentTime
    let
        now = nanosSinceEpoch utc_time
        utc_time_filter = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_time) - 10800)
    mysql_lag <- getMysqlMaxTime "txn_detail" utc_time_filter
    mysql_order_lag <- getMysqlMaxTime "order_reference" utc_time_filter
    mysql_refund_lag <- getMysqlMaxTime "refund" utc_time_filter
    gkeTimeColumn <- getGkeTimeColumn
    gkeTableName <- getGkeTableName
    ckh_gke_lag <- getCkhGkeMaxTimestamp  gkeTimeColumn gkeTableName utc_time_filter
    ckh_gke_order_lag <- getCkhGkeMaxTimestamp  gkeTimeColumn "express_checkout_v2.orders_v2" utc_time_filter
    ckh_nile_lag <- getCkhNileMaxTimestamp utc_time_filter
    bqProjectId <- getBqProjectId
    bq_lag <- getBqMaxTimestamp bqProjectId utc_time_filter utc_time
    lagCounter <- P.register $ P.vector ("table_name", "data_source") $ P.counter (P.Info "data_lag" "")
    let
        reference_txn_timestamp = (if (length mysql_lag) > 0 then  latestTime (head mysql_lag) else (fromIntegral 0 :: Int))
        reference_order_timestamp =  (if (length mysql_order_lag) > 0 then  latestTime (head mysql_order_lag) else (fromIntegral 0 :: Int))                           
        reference_refund_timestamp = (if (length mysql_refund_lag) > 0 then  latestTime (head mysql_refund_lag) else (fromIntegral 0 :: Int))
    
        ckh_nile_latest_ts =  case (getLatest "dashboards.vision_realtime_view" ckh_nile_lag) of
                                    Just a -> a
                                    Nothing -> 0
        ckh_nile_api_latest_ts= case (getLatest "dashboards.api_requests_app" ckh_nile_lag) of
                                    Just a -> a
                                    Nothing -> 0
        ckh_nile_ref_latest_ts= case (getLatest "dashboards.vision_refunds_view" ckh_nile_lag) of
                                    Just a -> a
                                    Nothing -> 0
        ckh_nile_gwy_latest_ts= case (getLatest "dashboards.gateway_score" ckh_nile_lag) of
                                    Just a -> a
                                    Nothing -> 0
        ckh_nile_mid_latest_ts= case (getLatest "dashboards.mid_outage_score" ckh_nile_lag) of
                                    Just a -> a
                                    Nothing -> 0

        ckh_gke_latest_ts = case (if (length ckh_gke_lag) > 0 then  (head ckh_gke_lag) ^? ix "latest" . _Number .to floor else Just (fromIntegral 0 :: Int)) of
                                    Just a -> a
                                    Nothing -> 0
        ckh_gke_ord_latest_ts = case (if (length ckh_gke_order_lag) > 0 then  (head ckh_gke_order_lag) ^? ix "latest" . _Number .to floor else Just (fromIntegral 0 :: Int)) of
                                    Just a -> a
                                    Nothing -> 0
        bq_lag_result = getBqResult bq_lag

        bq_ec_latest_ts = case (getLatestfromBqResult "express_checkout_v2.express_checkout" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        bq_ec_sessions_latest_ts = case (getLatestfromBqResult "express_checkout_sessions_v2.ec_sessions" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        bq_ec_ref_latest_ts = case (getLatestfromBqResult "express_checkout_v2.ec_refund" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        bq_vision_txn_latest_ts = case (getLatestfromBqResult "vision.euler_sessions_v2" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        bq_vision_api_latest_ts = case (getLatestfromBqResult "vision.euler_api_requests_v2" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        bq_vision_gwy_latest_ts = case (getLatestfromBqResult "vision.gateway_score" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        bq_vision_mid_latest_ts= case (getLatestfromBqResult "vision.mid_outage_score" bq_lag_result) of
                                    Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                                    Nothing -> 0
        
        bq_ec_lag = reference_txn_timestamp - bq_ec_latest_ts
        bq_vision_txn_lag = reference_txn_timestamp - bq_vision_txn_latest_ts
        bq_vision_api_lag = now - bq_vision_api_latest_ts
        bq_vision_gwy_lag = now - bq_vision_gwy_latest_ts
        bq_vision_mid_lag = now - bq_vision_mid_latest_ts
        bq_ec_session_lag= reference_txn_timestamp - bq_ec_sessions_latest_ts
        bq_ec_ref_lag= reference_refund_timestamp - bq_ec_sessions_latest_ts
        ckh_gke_lagg = reference_txn_timestamp - ckh_gke_latest_ts
        ckh_gke_ord_lag = reference_order_timestamp - ckh_gke_ord_latest_ts
        ckh_nile_lagg = reference_txn_timestamp - ckh_nile_latest_ts
        ckh_nile_api_lag = now - ckh_nile_api_latest_ts
        ckh_nile_ref_lag = reference_refund_timestamp - ckh_nile_ref_latest_ts
        ckh_nile_gwy_lag = now - ckh_nile_gwy_latest_ts
        ckh_nile_mid_lag = now - ckh_nile_mid_latest_ts
    

    updateMetrics lagCounter "express_checkout_v2.express_checkout" "BigQuery" bq_ec_lag
    updateMetrics lagCounter "vision.euler_sessions_v2" "BigQuery" bq_vision_txn_lag
    updateMetrics lagCounter "vision.euler_api_requests_v2" "BigQuery" bq_vision_api_lag
    updateMetrics lagCounter "vision.gateway_score" "BigQuery" bq_vision_gwy_lag
    updateMetrics lagCounter "vision.mid_outage_score" "BigQuery" bq_vision_mid_lag
    updateMetrics lagCounter "express_checkout_sessions_v2.ec_sessions" "BigQuery" bq_ec_session_lag
    updateMetrics lagCounter "express_checkout_v2.ec_refund" "BigQuery" bq_ec_ref_lag
    updateMetrics lagCounter "$GKE_TABLE_NAME" "ClickhouseGKE" ckh_gke_lagg
    updateMetrics lagCounter "express_checkout_v2.orders_v2" "ClickhouseGKE" ckh_gke_ord_lag
    updateMetrics lagCounter "$NILE_TABLE_NAME" "ClickhouseNile" ckh_nile_lagg
    updateMetrics lagCounter "dashboards.api_requests_app" "ClickhouseNile" ckh_nile_api_lag
    updateMetrics lagCounter "dashboards.vision_refunds_view" "ClickhouseNile" ckh_nile_ref_lag
    updateMetrics lagCounter "dashboards.gateway_score" "ClickhouseNile" ckh_nile_gwy_lag
    updateMetrics lagCounter"dashboards.mid_outage_score" "ClickhouseNile" ckh_nile_mid_lag



    return ()
    where
        updateMetrics counter_ table_name data_source val = 
            replicateM_ val (P.withLabel counter_ (table_name, data_source) P.incCounter)

getLatest :: T.Text -> [Value] -> Maybe Int
getLatest _ [] = Nothing
getLatest val (x:xs) = if (fromJust (x ^? ix "table_name" . _String)) ==  val then (x ^? ix "latest" . _Number .to floor) else getLatest val xs

getLatestfromBqResult :: T.Text -> [[T.Text]] -> Maybe T.Text
getLatestfromBqResult _ [] = Nothing
getLatestfromBqResult val (x:xs) = if (fromJust (x ^? ix 1) ) == val then (x ^? ix 0) else getLatestfromBqResult val xs


getMysqlMaxTime :: String -> UTCTime -> IO [LagMysql]
getMysqlMaxTime tb utcTime = do
        dbConfig <- getDbConfig
        conn <- connect dbConfig
        let qry = fromString (TL.unpack("use jpdb; select UNIX_TIMESTAMP(max(date_created)) as latest from " 
                                <> TL.pack(tb) <> " where date_created >= '" 
                                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) <> "';"))
        mysql_max_timestamp <- query_ conn qry :: IO [LagMysql]
        return(mysql_max_timestamp)


getCkhGkeMaxTimestamp :: String -> String -> UTCTime -> IO [Value]
getCkhGkeMaxTimestamp timemColumn tb utcTime = do
    gkeHost <- getGkeHost
    gkeUser <- getGkeUser
    gkePassword <- getGkePassword
    latestTimestamp <- fetchRecord (makeRequestBodyFromText (T.pack(TL.unpack("SELECT toUnixTimestamp(max(" 
                        <> TL.pack(timemColumn) <> ")) as latest FROM " 
                        <> TL.pack(tb) <> " WHERE " 
                        <> TL.pack(timemColumn) <> " >= '" 
                        <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) 
                        <> "' FORMAT JSONEachRow")))) gkeHost gkeUser gkePassword
    return(latestTimestamp)

getCkhNileMaxTimestamp :: UTCTime -> IO [Value]
getCkhNileMaxTimestamp utcTime = do
    let query = "SELECT max(toUnixTimestamp(date)) as latest, 'dashboards.api_requests_app' as table_name FROM dashboards.api_requests_app WHERE date >= '" 
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) 
                <> "' UNION ALL SELECT max(toUnixTimestamp(created_at)) as latest, 'dashboards.vision_refunds_view' as table_name FROM dashboards.vision_refunds_view WHERE created_at >= '" 
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) 
                <> "' UNION ALL SELECT max(toUnixTimestamp(timestamp)) as latest, 'dashboards.gateway_score' as table_name FROM dashboards.gateway_score WHERE timestamp >= '" 
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) 
                <> "' UNION ALL SELECT max(toUnixTimestamp(timestamp)) as latest, 'dashboards.mid_outage_score' as table_name FROM dashboards.mid_outage_score WHERE timestamp >= '" 
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) 
                <> "' UNION ALL SELECT max(toUnixTimestamp(txn_created_at)) as latest, 'dashboards.vision_realtime_view' as table_name FROM dashboards.vision_realtime_view WHERE txn_created_at >= '" 
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime))) 
                <> "' FORMAT JSONEachRow"
    ckhNileHost <- getNileHost
    ckhNileUser <- getNileUser
    ckhNilePassword <- getNilePassword
    latestTimestamp <- fetchRecord (makeRequestBodyFromText (T.pack(TL.unpack(query)))) ckhNileHost ckhNileUser ckhNilePassword
    return(latestTimestamp)

getBqMaxTimestamp :: String -> UTCTime -> UTCTime -> IO GBT.QueryResponse
getBqMaxTimestamp bqProjectId utcTime curr_time = do
    let query = "( SELECT UNIX_SECONDS(MAX(TIMESTAMP(timestamp))) AS latest, 'vision.gateway_score' AS table_name FROM " 
                <> TL.pack(bqProjectId) <> ".vision.gateway_score WHERE timestamp >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') \
                \UNION ALL \
                \( SELECT UNIX_SECONDS(MAX(TIMESTAMP(timestamp))) AS latest,'vision.mid_outage_score' AS table_name FROM "
                <> TL.pack(bqProjectId) <>".vision.mid_outage_score WHERE timestamp >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') \
                \UNION ALL \
                \( SELECT UNIX_SECONDS(MAX(TIMESTAMP(txn_initiated))) AS latest, 'express_checkout_sessions_v2.ec_sessions' AS table_name FROM "
                <> TL.pack(bqProjectId) <>".express_checkout_sessions_v2.ec_sessions" <> (TL.pack(formatTime defaultTimeLocale "%Y%m%d" (curr_time))) <> " WHERE txn_initiated >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') \
                \UNION ALL \
                \(SELECT UNIX_SECONDS(MAX(TIMESTAMP(txn_initiated))) AS latest, 'express_checkout_v2.express_checkout' AS table_name FROM "
                <> TL.pack(bqProjectId) <>".express_checkout_v2.express_checkout" <> (TL.pack(formatTime defaultTimeLocale "%Y%m%d" (curr_time))) <> " WHERE txn_initiated >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') \
                \UNION ALL \
                \(SELECT UNIX_SECONDS(MAX(TIMESTAMP(refund_date))) AS latest, 'express_checkout_v2.ec_refund' AS table_name FROM "
                <> TL.pack(bqProjectId) <>".express_checkout_v2.ec_refund" <> (TL.pack(formatTime defaultTimeLocale "%Y%m%d" (curr_time))) <> " WHERE refund_date >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') \
                \UNION ALL \
                \( SELECT UNIX_SECONDS(MAX(TIMESTAMP(txn_created_at))) AS latest, 'vision.euler_sessions_v2' AS table_name FROM "
                <> TL.pack(bqProjectId) <>".vision.euler_sessions_v2 WHERE txn_created_at >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') \
                \UNION ALL \
                \ ( SELECT UNIX_SECONDS(MAX(TIMESTAMP(date))) AS latest, 'vision.euler_api_requests_v2' AS table_name FROM "
                <> TL.pack(bqProjectId) <>".vision.euler_api_requests_v2 WHERE date >= '"
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utcTime)))<> "') "

    latest_timestamp <- getBQResponse (T.pack(TL.unpack(query)))
    return(latest_timestamp)

getDataAccuracy :: IO ()
getDataAccuracy = do
    utc_time <- getCurrentTime
    let
        utc_st = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_time) - 960)
        utc_et = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_time) - 900)
        ist_st = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_st) + 19800)
        ist_et = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_et) + 19800)
        rt_utc_st = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_time) - 240)
        rt_utc_et = posixSecondsToUTCTime ((utcTimeToPOSIXSeconds utc_time) - 180)
    nileTableName <- getNileTableName
    let query = "SELECT SUM(sign) as cnt," <> " actual_payment_status" 
                <> " as status FROM " <> TL.pack(nileTableName) 
                <> " WHERE txn_created_at >= " <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (ist_st))) 
                <> " AND txn_created_at <= " <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (ist_et))) 
                <> " GROUP BY " <> "actual_payment_status" <> " ORDER BY " <> "actual_payment_status" 
                <> " FORMAT JSONEachRow settings output_format_json_quote_64bit_integers = 0"
    dbConfig <- getDbConfig
    conn <- connect dbConfig
    bqTableName <- getBqTableName
    bq_status_count <-  getBQResponse (T.pack(TL.unpack("SELECT count(txn_detail_id) as cnt, status FROM "<> TL.pack(bqTableName) <> (TL.pack(formatTime defaultTimeLocale "%Y%m%d" (utc_st))) <> " WHERE txn_initiated >= '" 
                <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utc_st))) 
                <> "' AND txn_initiated <= '" <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utc_et))) 
                <> "' group by status order by status")))
    let bq_result = getBqResult bq_status_count
    ckhNileHost <- getNileHost
    ckhNileUser <- getNileUser
    ckhNilePassword <- getNilePassword
    gkeHost <- getGkeHost
    gkeUser <- getGkeUser
    gkePassword <- getGkePassword

    mysql_status_count <- query_ conn (fromString (TL.unpack("use jpdb; select count(id) as cnt, status as status from txn_detail where date_created >= " 
                            <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utc_st))) <> " and date_created <= " 
                            <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (utc_st))) 
                            <> " group by status order by status;"))) :: IO [AccuracyMysql]
    mysql_rt_status_count <- query_ conn (fromString (TL.unpack("use jpdb; select count(id) as cnt, status as status from txn_detail where date_created >= " 
                            <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (rt_utc_st))) <> " AND date_created <= " 
                            <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (rt_utc_et))) 
                            <> " group by status order by status;"))) :: IO [AccuracyMysql]
    gkeTableName <- getGkeTableName
    ckh_gke_status_count <- fetchRecord (makeRequestBodyFromText (T.pack(TL.unpack("SELECT SUM(sign) as cnt, txn_status as status FROM " <> TL.pack(gkeTableName) <> " WHERE created_at_ist >= " 
                            <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (ist_st))) <> " AND created_at_ist <= " 
                            <> (TL.pack(formatTime defaultTimeLocale "%Y-%m-%d %H:%M:%S" (ist_et))) 
                            <> " GROUP BY txn_status ORDER BY txn_status FORMAT JSONEachRow settings output_format_json_quote_64bit_integers = 0")))) gkeHost gkeUser gkePassword
    ckh_nile_status_count <- fetchRecord (makeRequestBodyFromText (T.pack(TL.unpack(query)))) ckhNileHost ckhNileUser ckhNilePassword
    lagCounter <- P.register $ P.vector ("table_name", "data_source", "status") $ P.counter (P.Info "data_accuracy" "")
    addMysqlDataToPrometheus lagCounter "cnt" "status" "txn_detail" "MySQL" mysql_status_count 
    addMysqlDataToPrometheus lagCounter "cnt" "status" "txn_detail" "MySQL-RT" mysql_rt_status_count
    addCkhDataToPrometheus lagCounter "cnt" "status" "express_checkout_v2.transactions_v2" "ClickhouseGKE" ckh_gke_status_count
    addCkhDataToPrometheus lagCounter "cnt" "status" "dashboards.vision_realtime_view" "ClickhouseNile" ckh_nile_status_count
    addBqDataToPrometheus lagCounter "express_checkout_v2.express_checkout" "BigQuery" bq_result
    return ()
    where
        updateMetrics counter_ table_name data_source val = 
            replicateM_ val (P.withLabel counter_ (table_name, data_source) P.incCounter)


addMysqlDataToPrometheus :: P.Vector (T.Text, T.Text, T.Text) P.Counter -> T.Text -> T.Text -> T.Text -> T.Text -> [AccuracyMysql] -> IO ()
addMysqlDataToPrometheus _ _ _ _ _ [] = return ()
addMysqlDataToPrometheus counter_ t1 t2 table_name data_source (x:xs) = do
    let
        val1 = count_ x
        val2 = status_ x
    replicateM_ val1 (P.withLabel counter_ (table_name, data_source, val2) P.incCounter)
    return ()


addCkhDataToPrometheus :: P.Vector (T.Text, T.Text, T.Text) P.Counter -> T.Text -> T.Text -> T.Text -> T.Text -> [Value] -> IO ()
addCkhDataToPrometheus _ _ _ _ _ [] = return ()
addCkhDataToPrometheus counter_ t1 t2 table_name data_source (x:xs) = do
    let 
        val1 = case (x ^? ix t1 . _Number .to floor) of
                Just a -> a
                Nothing -> 0
        val2 = case (x ^? ix t2 . _String) of
                Just a -> a
                Nothing -> ""
    replicateM_ val1 (P.withLabel counter_ (table_name, data_source, val2) P.incCounter)
    return ()

addBqDataToPrometheus :: P.Vector (T.Text, T.Text, T.Text) P.Counter -> T.Text -> T.Text -> [[T.Text]] -> IO ()
addBqDataToPrometheus _ _ _ [] = return ()
addBqDataToPrometheus counter_ table_name data_source (x:xs) = do
    let 
        val1 = case (x ^? ix 0) of
                Just a -> case (readMaybe (T.unpack(a)) :: Maybe Int) of
                                                Just b -> b
                                                Nothing -> 0
                Nothing -> 0
        val2 = case (x ^? ix 1) of
                Just a -> a
                Nothing -> ""
    replicateM_ val1 (P.withLabel counter_ (table_name, data_source, val2) P.incCounter)
    return ()

buildRequest :: String -> NHC.RequestBody -> String -> String -> IO NHC.Request
buildRequest url body user key= do
    nakedRequest <- NHC.parseRequest url
    return (nakedRequest { NHC.method = "POST", NHC.requestBody = body, NHC.requestHeaders = NHC.requestHeaders nakedRequest <> [("X-ClickHouse-User", B.pack user), ("X-ClickHouse-Key", B.pack key)] })



fetchRecord :: NHC.RequestBody -> String -> String -> String -> IO [Value]
fetchRecord requestBody host user key = do
  manager <- NHC.newManager NHC.defaultManagerSettings
  request <- buildRequest host requestBody user key
  response <- NHC.httpLbs request manager
  let st = BLC.lines (NHC.responseBody response)
  return (mapMaybe decode st)

makeRequestBodyFromText :: T.Text -> NHC.RequestBody
makeRequestBodyFromText text =  NHC.RequestBodyBS $ TE.encodeUtf8 $ text


getBQResponse :: T.Text -> IO GBT.QueryResponse
getBQResponse query =  do
    bqProjectId <- getBqProjectId
    let
        queryRequest = GBT.QueryRequest Nothing Nothing Nothing Nothing "bigquery#queryRequest" Nothing (Just "asia-south1") Nothing Nothing Nothing Nothing (Just query) Nothing Nothing Nothing False False
        bigQueryJobsQuery = GBQ.BigQueryJobsQuery queryRequest (T.pack bqProjectId)
    lgr  <- Google.newLogger Google.Error stdout
    manager <- newTlsManagerWith tlsManagerSettings
    googleEnv <-
            Google.newEnv
              <&>
                (Google.envLogger .~ lgr)
                . (Google.envScopes .~ (Proxy :: Proxy '[GB.Bigquery'FullControl])) 
                . (Google.envManager .~ manager)
    bqRes <- liftIO $ runResourceT $ Google.send googleEnv mempty bigQueryJobsQuery
    return (bqRes)

getBqResult :: GBT.QueryResponse -> [[T.Text]]
getBqResult res = fmap DV.toList (DV.toList result)
                where
                    rows = fromJust ((toJSON res) ^? ix "rows" . _Array)
                    mapOverRows = fmap (fmap fromJust (^? ix "f" . _Array)) rows
                    mapOverRowsValue = fmap (fmap (^? ix "v" . _String)) mapOverRows
                    result = fmap (fmap fromJust ) mapOverRowsValue