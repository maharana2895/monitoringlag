{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE BangPatterns #-}
module Config where

import Database.MySQL.Simple
import Database.MySQL.Simple.QueryResults
import Database.MySQL.Simple.Result
import Data.Text as T
import Data.Maybe
import System.Environment
import GHC.Generics (Generic)
import Data.Aeson(FromJSON(parseJSON), decodeFileStrict')

data LagMysql = LagMysql {
    latestTime :: Int
} deriving (Show, Generic, FromJSON)

data AccuracyMysql = AccuracyMysql {
    count_ :: Int
   ,status_ :: T.Text
} deriving (Show, Generic, FromJSON)

instance QueryResults LagMysql where
    convertResults [fa] [va] = LagMysql a 
        where !a = convert fa va
    convertResults fs vs  = convertError fs vs 1

instance QueryResults AccuracyMysql where
    convertResults [fa, fb] [va, vb] = AccuracyMysql a b
        where !a = convert fa va
              !b = convert fb vb
    convertResults fs vs  = convertError fs vs 2

getDbConfig :: IO ConnectInfo
getDbConfig = do
    mysqlDbHost <- getMysqlDbHost
    mysqlDbDatabase <- getMysqlDbDatabase
    mysqlDbUser <- getMysqlDbUser
    mysqlDbPassword <- getMysqlDbPassword
    return defaultConnectInfo
        { connectHost = mysqlDbHost
        , connectDatabase = mysqlDbDatabase
        , connectUser = mysqlDbUser
        , connectPassword = mysqlDbPassword
        -- , connectPath = "/tmp/mysql.sock"
        }

getMysqlDbHost :: IO String
getMysqlDbHost = fromMaybe (error "MYSQL_DB_HOST not present in ENV") <$> (lookupEnv "MYSQL_DB_HOST")

getMysqlDbDatabase :: IO String
getMysqlDbDatabase = fromMaybe (error "MYSQL_DB_DATABASE not present in ENV") <$> (lookupEnv "MYSQL_DB_DATABASE")

getMysqlDbUser :: IO String
getMysqlDbUser = fromMaybe (error "MYSQL_DB_USER not present in ENV") <$> (lookupEnv "MYSQL_DB_USER")

getMysqlDbPassword :: IO String
getMysqlDbPassword = fromMaybe (error "MYSQL_DB_PASSWORD not present in ENV") <$> (lookupEnv "MYSQL_DB_PASSWORD")

getNileHost :: IO String 
getNileHost = fromMaybe (error "CKH_NILE_HOST not present in ENV") <$> (lookupEnv "NILE_HOST")

getNileUser :: IO String
getNileUser = fromMaybe (error "CKH_NILE_USER not present in ENV") <$> (lookupEnv "NILE_USER")

getNilePassword :: IO String
getNilePassword = fromMaybe (error "CKH_NILE_PASSWORD not present in ENV") <$> (lookupEnv "NILE_PASSWORD")

getGkeHost :: IO String
getGkeHost = fromMaybe (error "GKE_HOST not present in ENV") <$> (lookupEnv "GKE_HOST")

getGkeUser :: IO String
getGkeUser = fromMaybe (error "GKE_USER not present in ENV") <$> (lookupEnv "GKE_USER")

getGkePassword :: IO String
getGkePassword = fromMaybe (error "GKE_PASSWORD not present in ENV") <$> (lookupEnv "GKE_PASSWORD")

getBqProjectId :: IO String
getBqProjectId = fromMaybe (error "BQ_PROJECT_ID not present in ENV") <$> (lookupEnv "BQ_PROJECT_ID")

getNileTimeColumn:: IO String
getNileTimeColumn = fromMaybe (error "NILE_TIME_COLUMN not present in ENV") <$> (lookupEnv "NILE_TIME_COLUMN")

getNileTableName :: IO String
getNileTableName = fromMaybe (error "NILE_TABLE_NAME not present in ENV") <$> (lookupEnv "NILE_TABLE_NAME")

getGkeTimeColumn:: IO String
getGkeTimeColumn = fromMaybe (error "GKE_TIME_COLUMN not present in ENV") <$> (lookupEnv "GKE_TIME_COLUMN")

getGkeTableName :: IO String
getGkeTableName = fromMaybe (error "GKE_TABLE_NAME not present in ENV") <$> (lookupEnv "GKE_TABLE_NAME")

getBqTableName :: IO String
getBqTableName = fromMaybe (error "BQ_TABLE_NAME not present in ENV") <$> (lookupEnv "BQ_TABLE_NAME")
